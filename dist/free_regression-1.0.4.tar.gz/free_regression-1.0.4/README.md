# free_regression

Construtor de regressão genérico.

# Download

```
pip install git+https://github.com/IanAguiar-ai/free_regression
```
