# free_regression

Construtor de regressão genérico.

# Download

```
pip install git+https://github.com/IanAguiar-ai/free_regression
```

# Documentação das classes e funções

A documentação gerada pelo Doxygen pode ser acessada [aqui](https://github.com/IanAguiar-ai/free_regression/blob/main/free_regression/documentacao/html/annotated.html).

## Criando regressores

### Geração de regressores (geradores)

### Regressores próprios

## Regressão

### Regressão direta

### Parâmetros de regressão

1. lock
2. change
3. change_all

## Predição

## Misturas

## Função de perda

## Gráficos

## Reutilização
