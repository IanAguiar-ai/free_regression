from .free_regression import Regression
from .graphics import plot_expected, plot_residual
