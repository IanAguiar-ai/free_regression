from .free_regression import Regression
