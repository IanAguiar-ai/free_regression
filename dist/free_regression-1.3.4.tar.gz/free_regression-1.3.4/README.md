# free_regression

Construtor de Regressão Genérico. Com esta biblioteca, o usuário é capaz de:

1. Criar regressões 'tradicionais' (seção **Geração de regressores**);
2. Criar regressões personalizadas (seção **Regressores próprios**);
3. Manipular as regressões;
4. Criar cadeias de Markov com n graus (seção **Generator**).


# Download

```
pip install git+https://github.com/IanAguiar-ai/free_regression
```

# Importação

Para importar a classe principal:

```
from free_regression import Regression
```

Para importar os geradores de funções:

```
from free_regression import generate_regression, generate_mlp, generate_mlp_classifier, generate_mlp_semi_classifier, generate_mlp_sigmoid_sum, generate_mlp_normals, generate_distribuction
```

Para importar as funções geradoras de imagens:

```
from free_regression import plot_expected, plot_residual, make_animation, plot_prediction_bands, plot_series
```

Para importar as funções de manipulação de dados:

```
from free_regression import to_dummy, transpose, normalize, data_series, round_series
```

Para importar funções de cadeia de Markov:

```
from free_regression import Generator
```

# Documentação das classes e funções

A documentação gerada pelo Doxygen pode ser acessada [aqui](https://github.com/IanAguiar-ai/free_regression/blob/main/free_regression/documentacao/html/annotated.html).

A classe principal que o usuário deve utilizar é a **Regression**, que recebe como argumentos:

- **function**: Função de regressão que o usuário deseja utilizar;
- **regressors**: Lista de strings que especifica os regressores utilizados. Não é necessário passar este parâmetro se a função possuir apenas o parâmetro *x* ou *x1, x2, ...* como regressor, por exemplo, `def f(x, b1, b2)` ou `def f(x1, x2, b1, b2)`;
- **loss_function**: Função de perda para encontrar o mínimo local. Por padrão, utiliza-se a função de mínimos quadrados.

Além disso, na classe principal, as variáveis às quais o usuário tem acesso são:

- **.params**: Parâmetros que serão encontrados;
- **.regressors**: Variáveis regressoras;
- **.iterations**: Número mínimo de iterações para convergência.

## Criando regressores

O usuário pode criar regressores de duas formas: utilizando as funções prontas ou desenvolvendo seus próprios regressores.

### Geração de regressores (geradores)

Se o usuário desejar utilizar um regressor próprio, ele possui algumas opções, como:

- **generate_regression**: Para regressão linear, recebe dois parâmetros: *regressors* e *degree*;
- **generate_mlp**: Para gerar um Multi Layer Perceptron, recebe dois parâmetros: *regressors* e *neurons*, utilizando ReLU para gerar a descontinuidade;
- **generate_mlp_classifier**: Para gerar um Multi Layer Perceptron classificador, recebe dois parâmetros: *regressors* e *neurons*, utilizando uma função sigmoide para gerar a descontinuidade;
- **generate_mlp_semi_classifier**: Para gerar um Multi Layer Perceptron com ReLUs na camada intemediária e uma sigmoide no último neurônio, recebe dois parâmetros: *regressors* e *neurons*, utilizando uma função sigmoide para gerar a descontinuidade;
- **generate_mlp_sigmoid_sum**: Para gerar um Multi Layer Perceptron com sigmoids na camada intermediária e sem função de ativação no ultimo neurônio, recebe dois parâmetros: *regressors* e *neurons*, utilizando uma função sigmoide para gerar a descontinuidade;
- **generate_mlp_sigmoid_sum**: Para gerar um Multi Layer Perceptron com *Radial Basis Function (RBF)* na camada intermediária e sem função de ativação no ultimo neurônio, recebe três parâmetros: *regressors*, *neurons* e *max*, utilizando uma função sigmoide para gerar a descontinuidade;
- **generate_distribuction**: Para gerar uma distribuição com integral de -infinito a +infinito sendo 1, usando *Radial Basis Function (RBF)*, recebe dois parâmetros: *regressors*, *normals*.
- **generate_neural_network**: Para gerar uma rede neural artificial genérica, recebe dois parâmetros: *struct*(lista com quantidade de inputs, neuronios em cada camada e output) e *activation*(funções de ativação usada em cada camada, como a primeira camada não conta temos uma lista de tamanho len(struct) - 1);
- **generate_linear_spline**: Para gerar um *spline* usando funções lineares separadas por limiares $l_i$, recebe um único parâmetro: *lines*(inteiro, quantidade de linhas).

Todas essas funções retornam dois elementos: a função em si e a lista de regressores.

```
funcao, regressores = generate_regression(regressors = 3, degree = 2)
meu_modelo_regressor = Regression(function = funcao, regressors = regressores)
meu_modelo.run(seus_dados) # Para começar a regressão
```

Ou

```
meu_modelo_regressor = Regression(*generate_regression(regressors = 3, degree = 2))
meu_modelo.run(seus_dados) # Para começar a regressão
```

Ou ainda

```
meu_modelo_regressor = Regression(generate_regression(regressors = 3, degree = 2))
meu_modelo.run(seus_dados) # Para começar a regressão
```

Para ver o resultado da regressão:

```
print(meu_modelo_regressor)

# Ou para ver os regressores individualmente
print(meu_modelo['str_nome_do_regressor'])
```

Todas os geradores são chamados pelo usuário da mesma forma, apenas mudando o nome da função.

### Exemplo rede neural com **generate_neural_network**

Se o usuário quiser por exemplo uma rede com 2 inputs, duas camadas intermediarias com 3 camadas e um output, e apenas a ultima camada é um sigmoid e os outros são relu, basta montalo desta forma:

```
modelo = Regression(generate_neural_network(struct = [2, 3, 3, 1], activation = ['relu', 'relu', 'sigmoid']))

print(modelo)
```

Saída:

```
FUNCTION: new_generate_neural_network_2_3_3_1
LOSS FUNCTION: least_squares
REGRESSORS: x_1, x_2
LENTH OUTPUT: 1 (UNIVARIATE)
PARAMS:
  c_0_0 = 0.10000000 (w: 1.00000000)
  c_0_1 = 0.10000000 (w: 1.00000000)
  c_1_0 = 0.10000000 (w: 1.00000000)
  b_1_0_0 = 0.10000000 (w: 1.00000000)
  b_1_0_1 = 0.10000000 (w: 1.00000000)
  c_1_1 = 0.10000000 (w: 1.00000000)
  b_1_1_0 = 0.10000000 (w: 1.00000000)
  b_1_1_1 = 0.10000000 (w: 1.00000000)
  c_1_2 = 0.10000000 (w: 1.00000000)
  b_1_2_0 = 0.10000000 (w: 1.00000000)
  b_1_2_1 = 0.10000000 (w: 1.00000000)
  c_2_0 = 0.10000000 (w: 1.00000000)
  b_2_0_0 = 0.10000000 (w: 1.00000000)
  b_2_0_1 = 0.10000000 (w: 1.00000000)
  b_2_0_2 = 0.10000000 (w: 1.00000000)
  c_2_1 = 0.10000000 (w: 1.00000000)
  b_2_1_0 = 0.10000000 (w: 1.00000000)
  b_2_1_1 = 0.10000000 (w: 1.00000000)
  b_2_1_2 = 0.10000000 (w: 1.00000000)
  c_2_2 = 0.10000000 (w: 1.00000000)
  b_2_2_0 = 0.10000000 (w: 1.00000000)
  b_2_2_1 = 0.10000000 (w: 1.00000000)
  b_2_2_2 = 0.10000000 (w: 1.00000000)
  c_3_0 = 0.10000000 (w: 1.00000000)
  b_3_0_0 = 0.10000000 (w: 1.00000000)
  b_3_0_1 = 0.10000000 (w: 1.00000000)
  b_3_0_2 = 0.10000000 (w: 1.00000000)
```

Tipos de ativação:

- relu
- sigmoid
- lrelu
- abs
- float
- int
- (função própria escrita no escopo global)

### Regressores próprios

Você pode criar regressores próprios para realizar a regressão, basta definir a função. Por exemplo:

Com regressor implicito
```
def minha_funcao(x:float, b1:float, b2:float) -> float:
	return x*b1 + b2
	
meu_modelo_regressor = Regression(minha_funcao)
print(meu_modelo_regressor) # Para ver as propriedades do modelo
meu_modelo_regressor.run(seus_dados) # Para começar a regressão
```

ou

```
def minha_funcao(x1:float, x2:float, b1:float, b2:float) -> float:
	return x1*b1 + x2*b2
	
meu_modelo_regressor = Regression(minha_funcao)
print(meu_modelo_regressor) # Para ver as propriedades do modelo
meu_modelo_regressor.run(seus_dados) # Para começar a regressão
```

Com regressor explicito
```
def minha_funcao(h:float, b1:float, b2:float) -> float:
	return h*b1 + b2
	
meu_modelo_regressor = Regression(minha_funcao, regressors = ["h"])
print(meu_modelo_regressor) # Para ver as propriedades do modelo
meu_modelo_regressor.run(seus_dados) # Para começar a regressão
```

O usuário pedindo *print(meu_modelo_regressor)* verá:

```
FUNCTION: minha_funcao
REGRESSORS: h
PARAMS:
  b1 = 0.10000000
  b2 = 0.10000000
```

É importante observar que todo regressor personalizado, ou seja, uma função regressora criada do zero, deve incluir os **regressores**, que são os parâmetros a serem preenchidos pelos dados, e os **parâmetros ajustáveis**, que são aqueles que o modelo irá estimar ao minimizar uma função de perda. Assim, ao criar a função regressora, o usuário deve garantir que ambos os tipos de parâmetros sejam definidos como *inputs* da função.

## Regressão

Comandos para fazer a regressão.

### Regressão direta

Para realizar uma regressão com a biblioteca, o usuário deve seguir os seguintes passos:

1. Definir ou criar a função de regressão que será utilizada;
2. Preparar os dados que serão usados na regressão. Os dados devem ser organizados em uma lista de listas, onde a última coluna corresponde ao valor esperado e as outras colunas são reservadas para os *x_n* (variáveis regressoras);
3. Executar o comando `.run(seus_dados)` na instância da classe **Regression**.

Em código, o passo a passo seria assim:

```
# Passo 1
funcao_regressora, argumentos = generate_regression(regressors = 2, degree = 1)
meu_modelo_regressor = Regression(funcao_regressora, argumentos)

# Passo 2
meus_dados = [[3, 2, 9], [2, 3, 1], [3, 5, 4], [2, 3, 1.3], [1, 3, 2], [7, 4, 20]]

# Passo 3
meu_modelo_regressor.run(meus_dados)

# Conferindo parâmetros atualizados
print(meu_modelo_regressor)
```

### Regressão robusta

Para realizar uma regressão semelhante ao método **.run**, mas de forma robusta:

```
from random import random

def regressao_simples(x:float, a:float, b:float) -> float:
    return a*x + b

dados = [*[[i, random() * 5 + i] for i in range(100)], *[[i, random() * 3] for i in range(30, 60, 2)]]
modelo1 = Regression(regressao_simples)
modelo1.run_robust(dados, especific_precision = [1, 0.1])

modelo2 = Regression(regressao_simples)
modelo2.run(dados, especific_precision = [1, 0.1])
```

### Regressão multivariada

Ainda é possível fazer regressões de $f(x_1, x_2, ...) = [y_1, y_2, ...]$:

```
def f(x1:float, x2:float, a:float, b:float, c:float) -> (float, float):
    return [x1*a + x2*b, x1*a - x2*c]

modelo = Regression(f, print = False)

a_, b_, c_ = 0.8, 3, -2
dados = [[0, 0, *f(0, 0, a_, b_, c_)],
         [1, 0, *f(1, 0, a_, b_, c_)],
         [0, 1, *f(0, 1, a_, b_, c_)],
         [1, 1, *f(1, 1, a_, b_, c_)],
         [2, 2, *f(2, 2, a_, b_, c_)],
         [1, 3, *f(1, 3, a_, b_, c_)],
         [3, 1, *f(3, 1, a_, b_, c_)],]

modelo.run(dados)
print(modelo)
```

Os dados no caso acima podiam estar dispostos de tal forma:

```
dados = [[0, 0, [3, 4]],
         [1, 0, [y1, y2]],
         ...]
```

ou

```
dados = [[0, 0, 3, 4],
         [1, 0, y1, y2],
         ...]
```

### Parâmetros de regressão

Além da regressão simples, é possível realizar diversas alterações nos parâmetros a fim de controlar melhor o processo de regressão. Algumas das funções embutidas na classe *Regression* são:

1. **.change**: Recebe cada parâmetro a ser modificado e o valor correspondente a essa alteração.

2. **.change_all**: Recebe um valor do tipo float que é aplicado a todos os parâmetros válidos.

3. **.lock**: Recebe cada parâmetro a ser bloqueado e o valor em que ele deve ser fixado. Após essa operação, esses parâmetros não são mais considerados na regressão, pois estão bloqueados.

A seguir, apresentamos um exemplo da função **.change**:

```
# Criando a função
def minha_funcao(x:float, b1:float, b2:float, b3:float) -> float:
	return b1*x**2 + x*b2 + b3

# Criando a instancia da classe
meu_modelo_regressor = Regression(minha_funcao)

# Antes da modificação
print(f"Antes:\n{meu_modelo_regressor}\n")

# Mudando os betas
meu_modelo_regressor.change(b1 = 2, b2 = 1.1, b3 = 15)
print(f"Depois do change:\n{meu_modelo_regressor}\n")

# Ou ainda pode mudar usando
meu_modelo_regressor['b1'] = 2
meu_modelo_regressor['b2'] = 1.1
meu_modelo_regressor['b3'] = 15
```

Exemplo do **.change_all**:

```
# Criando a função
def minha_funcao(x:float, b1:float, b2:float, b3:float) -> float:
	return b1*x**2 + x*b2 + b3

# Criando a instancia da classe
meu_modelo_regressor = Regression(minha_funcao)

# Antes da modificação
print(f"Antes:\n{meu_modelo_regressor}\n")

# Mudando os betas
meu_modelo_regressor.change_all(10)
print(f"Depois do change:\n{meu_modelo_regressor}\n")
```

Exemplo do **.lock**:

```
# Criando a função
def minha_funcao(x:float, b1:float, b2:float, b3:float) -> float:
	return b1*x**2 + x*b2 + b3

# Criando a instancia da classe
meu_modelo_regressor = Regression(minha_funcao)

# Antes da modificação
print(f"Antes:\n{meu_modelo_regressor}\n")

# Mudando os betas
meu_modelo_regressor.lock(b3 = 20)
print(f"Depois do lock:\n{meu_modelo_regressor}\n")

# Fazendo a regressão
meu_modelo_regressor.run(seus_dados)
print(f"Depois do lock e do run:\n{meu_modelo_regressor}\n")
# Perceba que as variáveis que estão bloqueadas não mudam mesmo depois da regressão
```

O **.change** e o **.change_all** servem para iniciar a regressão a partir de um ponto diferente, sendo que, por padrão, todos os valores começam em 0.1. Caso o usuário fique preso em um mínimo local indesejado, ele pode modificar tanto todos os parâmetros quanto parâmetros específicos.

O **.lock** pode ser utilizado para travar, por exemplo, um intercepto.

O uso dessas técnicas requer um conhecimento um pouco mais aprofundado sobre a função de regressão utilizada.


## Predição

Após o usuário realizar a regressão, é interessante que ele possa prever valores desconhecidos. Para isso, ele deve utilizar a função **.prediction** da classe *Regression*. Um exemplo de uso pode ser visto a seguir:

```
# Criando a função
def minha_funcao(x:float, b1:float, b2:float, b3:float) -> float:
	return b1*x**2 + x*b2 + b3

# Criando a instancia da classe
meu_modelo_regressor = Regression(minha_funcao)

# Fazendo a regressão
meu_modelo_regressor.run(seus_dados)

# Predição
resposta = meu_modelo_regressor.prediction(x = 4)
# Ou
resposta = meu_modelo_regressor(x = 4)


print(f"Predição para x = 4: {resposta}")
```

```
# Criando a função
def minha_funcao(x1:float, x2:float, b1:float, b2:float, b3:float) -> float:
	return x1*b1 + x2*b2 + b3

# Criando a instancia da classe
meu_modelo_regressor = Regression(minha_funcao, regressors = ["x1", "x2"])

# Fazendo a regressão
meu_modelo_regressor.run(seus_dados)

# Predição
resposta = meu_modelo_regressor.prediction(x1 = 2, x2 = 1.2)
# Ou
resposta = meu_modelo_regressor(x1 = 2, x2 = 1.2)

print(f"Predição para x1 = 2 e x2 = 1.2: {resposta}")
```

Ou ainda uma lista de valores a serem preditos:

```
# Criando a função
def minha_funcao(x1:float, x2:float, b1:float, b2:float, b3:float) -> float:
	return x1*b1 + x2*b2 + b3

# Criando a instancia da classe
meu_modelo_regressor = Regression(minha_funcao, regressors = ["x1", "x2"])

# Fazendo a regressão
meu_modelo_regressor.run(seus_dados)

# Predição
resposta = meu_modelo_regressor.prediction([[2, 1.2], [3, 1], [1, 1]])
# Ou
resposta = meu_modelo_regressor([[2, 1.2], [3, 1], [1, 1]])

print(f"Predição: {resposta}")
```

## Misturas

É possível fazer a mistura de funções de regressão, por exemplo:

```
# Criando as funções para a mistura

def parte_1(x, a, b):
	return a*x**3 + b*x**2
	
def parte_2(x, c):
	return c*x
	
# Fanzendo a mistura das regressões
meu_modelo_parte_1 = Regression(parte_1)
meu_modelo_parte_2 = Regression(parte_2)

meu_modelo_final = meu_modelo_parte_1 + meu_modelo_parte_2 - 20

print(f"Modelo mistura: {meu_modelo_final}")
```

Perceba que, no caso acima, obtemos \( ax^3 + bx^2 + cx - 20 \).

É possível criar modelos de mistura utilizando os operadores '+', '-', '*', '/', e '**'. Se o usuário desejar usar um operador diferente, basta utilizar a função **.operation** da classe *Regression*. Por exemplo:


```
# Criando as funções para a mistura

def parte_1(x, a, b):
	return a*x**3 + b*x**2
	
def parte_2(x, c):
	return c*x
	
# Fanzendo a mistura das regressões
meu_modelo_parte_1 = Regression(parte_1)
meu_modelo_parte_2 = Regression(parte_2)

meu_modelo_final = meu_modelo_parte_1.operation(meu_modelo_parte_2, operator = "%")

print(f"Modelo mistura: {meu_modelo_final}")
```

Atenção: observe que a mistura é feita da esquerda para a direita. Por exemplo, \( a + b / c \) é sempre \( (a + b) / c \) e não \( a + (b / c) \).

## Função de perda

A função de perda é, por padrão, uma função de mínimos quadrados, sendo essa a sua forma específica:

```
def least_squares(vector_1:list, vector_2:list) -> float:
    """
    Função de minimos quadrados
    """
    return sum([(vector_1[i] - vector_2[i])*(vector_1[i] - vector_2[i]) for i in range(len(vector_1))])
```

Contudo, se o usuário seguir o padrão de criar uma função de perda que utiliza os dois vetores passados—sendo o vetor dos valores observados e o vetor dos valores preditos nessa ordem—é possível alterar a função de perda com a função **.loss_function** da classe *Regression*. Por exemplo:

```
# Criando função de perda
def perda_modificada(v_1:list, v_2:list) -> float:
	"""
	Função de perda que da mais pesso para perdas para valores abaixo do observado
	"""
	perda = 0
	for i in range(len(v_1)):
		if v_1 > v_2:
			perda += (v_1[i] - v_2[i])**2
		else:
			perda += (v_2[i] - v_1[i])/10
	return perda    	


# Definindo a função criada como a loss_function
meu_modelo.loss_function(perda_modificada)

# Fazer a regressão com a função de perda modificada
meu_modelo.run(seus_dados)
```

## Reutilização

### Salvando e reutilizando parâmetros

Assim que a regressão é realizada, é possível salvar os parâmetros. Para isso, basta utilizar a função **.save** da classe *Regression*. Por exemplo:

```
# Depois de treinar o modelo...

# Salvando
meu_modelo.save(name = "nome_do_modelo")
```

Isso salvará, na mesma pasta em que o código Python estiver sendo executado, um arquivo *.memory*, que pode ser acessado posteriormente por uma instância da classe *Regression* construída da mesma forma:

```
# Criar modelo vazio
meu_modelo = Regression()

# Puxar os parâmetros
meu_modelo.open(name = "nome_do_modelo") # Não é preciso colocar o ".memory" no final do nome do modelo
```

### Passando parâmetros de uma instancia para a outra

É possível transferir parâmetros comuns de uma instância para outra. Por exemplo:

```
def func_1(x, a, b):
	return a*x**3 + b*x**2
	
def func_2(x, b, c):
	return c*x + b

meu_modelo_1 = Regression(func_1)
meu_modelo_2 = Regression(func_2)

meu_modelo_2["b"] = 1.234
meu_modelo_1 << meu_modelo_2

print(meu_modelo_1)
```

No caso acima, o valor do parâmetro *b* (parâmetro em comum) do *meu_modelo_2* é transferido para o *meu_modelo_1*.

### Setar *seed*

A função **.set_seed** da classe *Regression* recebe um número inteiro e define a *seed* do processo, garantindo reprodutibilidade. Exemplo:

```
meu_modelo = Regression(func_1)
meu_modelo.set_seed(1)
```

## Manipulação de dados

### *to_dummy*

Existem funções que auxiliam o usuário no tratamento dos dados. Por exemplo, a função **to_dummy**. Essa função recebe uma lista de listas, onde algumas colunas são categóricas, e, desde que todas as categorias estejam presentes nas variáveis categóricas, ela cria novas colunas dummy para cada categoria, em ordem alfabética, por coluna categórica. Exemplo:

```
dados = [[1, "a", 5, "1"],
         [3, "b", 6, "2"],
         [0, "a", 4, "1"],
         [6, "c", 3, "2"],
         [4, "a", 4, "2"],]

print(to_dummy(dados))
```

Retorna:

```
[[1, 5, 1, 0, 1],
 [3, 6, 0, 1, 0],
 [0, 4, 1, 0, 1],
 [6, 3, 0, 0, 0],
 [4, 4, 1, 0, 0]]
```

Antes existia 4 colunas, as colunas 0 e 2 são numéricas e as colunas 1 e 3 são categóricas, a função **to_dummy** pega a lista, apaga as colunas categóricas, e concatena essas colunas tiradas como *dummys* no final da lista.

A dimensão da coluna que era 4 agora se torna 1(numerica 0) + 1(numerica 2) + 2(dummy coluna 1, que tinha 3 categorias) + 1(dummy coluna 3 que tinha 2 categorias) = 5. Perceba que a nova dimensão dos dados é:

```
numericas = 2 # colunas
categorica_1 = ['a', 'b', 'c']
categorica_1 = ['1', '2']

total = numericas + (len(categorica_1) - 1) (len(categorica_2) - 1)
```

### *transpose*

Transpõe a lista de listas. Exemplo:

```
dados = [
 [1, 5],
 [3, 6],
 [0, 4],
 [6, 3],
 [4, 4]
 ]
```

Se torna:

```
dados = transpose(dados)

[[1, 3, 0, 6, 4],
 [5, 6, 4, 3, 4]]
```

É últil para montar os dados especificando colunas como é mostrado na seção 'Dados próprios'.

### *normalize*

Normaliza a lista de listas.

Recebe dois argumentos:

- **data**: Lista de listas que será normalizada.
- **only_y**: Variável booleana, por padrão é *False*, indica se só a última coluna (Y) deve ser normalizada, caso contrário, todas as colunas são normalizadas entre 0 e 1.

### *data_series*

Cria um lista de listas para modelos de séries temporais.

...

### *round_series*

Arredonda a série temporal.

...

### *exponential_smoothing*

Suavização exponencial.

...

### *double_exponential_smoothing*

Suavização exponencial dupla.

...

### *memory_alpha*

...

## Gráficos

### *plot_expected*

Função que recebe:

- **regression**: Instância da classe *Regression*;
- **data**: Dados em lista de listas;
- **size**: Tamanho da figura.

Esta função gera um plot simples que compara os valores observados com os valores preditos. Se os valores observados puderem ser representados como uma série, a função o fará; caso contrário, apresentará os dados observados como pontos.

### *plot_residual*

Função que recebe:

- **regression**: Instância da classe *Regression*;
- **data**: Dados em lista de listas;
- **size**: Tamanho da figura;
- **percentile**: Lista com dois percentis que serão apresentados no plot.

Esta função gera um histograma com a distribuição dos resíduos.

### *plot_prediction_bands*

Função que recebe:

- **regression**: Instância da classe *Regression*;
- **data**: Dados em lista de listas;
- **size**: Tamanho da figura;
- **percentile**: Lista com dois percentis que serão apresentados no plot;
- **sigma**: Float que controla a banda de confiança;
- **amplitude**: Float que controla o nível de amplitude que calcula a variância móvel, esse valor segue a escala dos dados no eixo *x*.

Esta função gera um histograma com a distribuição dos resíduos e com uma banda de confiança móvel que segue o **sigma** e o **percentile**.

### *plot_series*

Função que recebe:

- **regression**: Instância da classe *Regression*;
- **data**: Dados em lista de listas;
- **size**: Tamanho da figura;
- **bins**: Quantidade de barras no histograma.

Esta função a predição da série temporal desde que ela tenha sido construida corretamente.

## Generator (MC e MCMC)

### *Generator*

Classe de geradores por Cadeia de Markov.

Recebe:

- **dependence**: Inteiro indicando número de dependência.

Exemplo:

```
texto_exemplo:str = "seu texto aqui"

for dependence in range(1, 10, 1):
  test = Generator(dependence = dependence)
  test.train(list(text))
  
  ### Descomente para ver as informações do gerador:
  #print(test.chain)
  #print(test.prob_chain)
  #print(test.choice(["t", "a"])) # Prováveis respostas após esses dois caracteres
  
  resp:str = test.make_text(list("Frase que gererá uma sequencia"), lenth = 200)
  print(f"\nDependenci: {'='*200}\n{dependence} -> {resp}\n")
```

### *plot_time_series*

...

### *mcmc_anomaly*

Função que identifica anomalias em séries temporais dado a probabilidade do acontecimento

Função que recebe:

- **series**: Lista com série que deve treinar a cadeia de Markov;
- **predict**: Lista com os dados que devem ser preditos, o tamanho dele deve ser pelo menos de dependence + 1;
- **porcentage**: Float que considera o limiar que será considerado anomalia;
- **runs**: Inteiro com quantidade de vezes que MCMC deve ser executado por elemento, recomendado é 1000;
- **plot**: Booleano que indica se deverá ser colocado o plot.

Retorna:

- Retorna uma lista do tamanho de (predict - dependence) mostrando quais pontos seriam anomalias.

Exemplo:

```
from free_regression import Generator, mcmc_anomaly
from random import random, seed
from math import cos

seed(0)
dados = [10 + int(random()+random()+random()+cos(i/10)*30) for i in range(50_000)]
dados_prev = dados[100:300]

respostas = mcmc_anomaly(dados, dados_prev,
                         dependence = 2,
                         percentage = 10)
```

## Salvar *plots* da iteração

A função *make_animation* que recebe:

- **obj**: Instância da classe *Regression*;
- **data**: Dados em lista de listas;

Salva em uma pasta no diretório atual, chamada *temporary*, todos os *plots* para chegar no resultado da regressão e gera um vídeo em *.mp4* dessa animação.

Exemplo:
```
teste_1 = Regression(*generate_mlp_normals(regressors = 1, neurons = 2, max_ = 1))
teste_1.set_seed(1)
teste_1.change(b = 0)

dados = [[0, 0], [1, 1], [2, 0], [2.1, 1], [2.12, 1], [2.5, 1], [3, 0]]

make_animation(teste_1, dados)
```

# Limitação da biblioteca

Dado o método de convergência, é muito fácil que a regressão fique presa em mínimos locais. Portanto, tenha atenção ao usar o gerador de MLP.

# Dicas

## Pré-regressão/treinamento

Se uma regressão não está apresentando boa precisão ou demora demais para chegar ao resultado esperado, é possível realizar uma regressão com maior precisão e, em seguida, com menor precisão. Por exemplo:

```
meu_modelo = Regression(*generate_regression(regressors = 2, degree = 1))

meu_modelo.run(seus_dados, precision = 1)
meu_modelo.run(seus_dados, precision = 0.001)
```

ou

```
meu_modelo = Regression(*generate_regression(regressors = 2, degree = 1))

meu_modelo.run(seus_dados, especific_precision = [100, 1, 0.001])
```

## Regressão/treinamento de forma dividida

O usuário ainda pode dividir os dados e treinar um modelo de cada vez. Isso faz sentido se o usuário deseja, por exemplo, modelar uma ação, aprendendo todo o histórico dela, e depois refazer a regressão com os últimos 30 dias, a fim de obter um viés mais recente da ação. Por exemplo:

```
meu_modelo = Regression(*generate_regression(regressors = 2, degree = 1))

meu_modelo.run(seus_dados[:])
meu_modelo.run(seus_dados[-30:])
```
## Problemas de *overflow* e truncamento

Nos geradores de regressões utilizados para classificação, ocasionalmente, quando o parâmetro precision no método *.run* é configurado com um valor muito elevado, o usuário pode enfrentar problemas de *overflow*, acompanhado pelo erro com o código de identificação 34. Nesses casos, recomenda-se que o usuário reduza o valor de precision para evitar esse erro.

# Exemplos

## Com dados artificiais

### Lineares e Descontinuos

```
dados = [*[[i, i] for i in range(0, 10)], *[[i, 20 - i] for i in range(10, 20)]]

teste_mlp = Regression(*generate_mlp(regressors = 1, neurons = 2))
teste_mlp.change_all(0)
teste_mlp.set_seed(2024)
teste_mlp.run(dados, precision = 0.01)
print(teste_mlp)


teste_reg = Regression(*generate_regression(regressors = 1, degree = 2))
teste_reg.set_seed(2024)
teste_reg.run(dados, precision = 0.001)
print(teste_reg)


dados_normalizado = normalize(dados, only_y = True)
teste_mlp_2 = Regression(*generate_mlp_classifier(regressors = 1, neurons = 8))
teste_mlp_2.set_seed(2024)
teste_mlp_2.run(dados_normalizado, precision = 0.01)
print(teste_mlp_2)


teste_mlp_3 = Regression(*generate_mlp_sigmoid_sum(regressors = 1, neurons = 5))
teste_mlp_3.set_seed(2024)
teste_mlp_3.change_all(0.1)
teste_mlp_3.run(dados, precision = 0.1)
print(teste_mlp_3)


plot_expected(teste_mlp, dados)
plot_expected(teste_reg, dados)
plot_expected(teste_mlp_2, dados_normalizado)
plot_expected(teste_mlp_3, dados)

plot_prediction_bands(teste_mlp, dados, amplitude = 1)
plot_prediction_bands(teste_reg, dados, amplitude = 1)
plot_prediction_bands(teste_mlp_2, dados_normalizado, amplitude = 1)
plot_prediction_bands(teste_mlp_3, dados, amplitude = 1)
```

![EX_1](free_regression/imagens_testes/reg_1_relu.png)

![EX_2](free_regression/imagens_testes/reg_2_pol2.png)

![EX_3](free_regression/imagens_testes/reg_3_sigmoid.png)

![EX_3_1](free_regression/imagens_testes/reg_3_1.png)

![EX_12](free_regression/imagens_testes/reg_12.png)

![EX_13](free_regression/imagens_testes/reg_13.png)

![EX_14](free_regression/imagens_testes/reg_14.png)

![EX_15](free_regression/imagens_testes/reg_15.png)

### Colocando pesos nas amostras

```
from random import random, seed

def loss(y1, y2):
  pesos = globals()["pesos"]
  return sum([(y1[i] - y2[i])*(y1[i] - y2[i])*pesos[i] for i in range(len(y1))])

def regressao_simples(x:float, a:float, b:float) -> float:
    return a*x + b

seed(1)
dados = [*[[i, random() * 10 + i] for i in range(100)], *[[i, random() * 10] for i in range(30, 100, 4)]]
pesos = [random()/(i+1)**2 for i in range(len(dados))]

modelo_normal = Regression(regressao_simples)
modelo_normal.loss_function(loss)
modelo_normal.run(dados, especific_precision = [1, 0.1])

print(modelo_normal)

plot_expected(modelo_normal, dados)
```

Saída:

```
FUNCTION: regressao_simples
LOSS FUNCTION(loss): 0.11023756
REGRESSORS: x
LENTH OUTPUT: 1 (UNIVARIATE)
PARAMS:
  a = 0.99507940 (w: 1.00000000)
  b = 2.96292225 (w: 0.15609214)
```

![EX_COM_PESOS_NAS_AMOSTRAS](free_regression/imagens_testes/com_pesos_nas_amostras.png)

### Com dados artificiais, regressão robusta

Para realizar uma regressão semelhante ao método **.run**, mas de forma robusta:

```
from random import random, seed

def regressao_simples(x:float, a:float, b:float) -> float:
    return a*x + b

seed(1)
dados = [*[[i, random() * 5 + i] for i in range(100)], *[[i, random() * 3] for i in range(30, 60, 2)]]

modelo_normal = Regression(regressao_simples)
modelo_normal.run(dados, especific_precision = [1, 0.1])

modelo_robust = Regression(regressao_simples)
modelo_robust.run_robust(dados, especific_precision = [1, 0.1])

print(modelo_normal)
print()
print(modelo_robust)

plot_expected(modelo_normal, dados)
plot_expected(modelo_robust, dados)
```

Saída:

```
FUNCTION: regressao_simples
LOSS FUNCTION(least_squares): 244.40520424
REGRESSORS: x
LENTH OUTPUT: 1 (UNIVARIATE)
PARAMS:
  a = 1.03362084 (w: 0.08661750)
  b = -4.98997949 (w: 1.00000000)
  
FUNCTION: regressao_simples
LOSS FUNCTION(least_squares): 1.77871458
REGRESSORS: x
LENTH OUTPUT: 1 (UNIVARIATE)
PARAMS:
  a = 1.01147102 (w: 0.00030542)
  b = 2.07874404 (w: 1.00000000)
```

![EX_robust_1](free_regression/imagens_testes/robust_1.png)

![EX_robust_2](free_regression/imagens_testes/robust_2.png)

### Teste com logisticas

```
def reg_log(x, b0, b1) -> float:
  return 1/(1 + 2.71**(-(b0*x+b1)))

dados_ = [[i/100, i/100] for i in range(100)]
modelo = Regression(reg_log)
modelo.set_seed(2024)
modelo.run(dados_, precision = 0.1)

print(modelo)
plot_expected(modelo, dados_)
plot_prediction_bands(modelo, dados_)

modelo = Regression(*generate_mlp_classifier(1,5))
modelo.set_seed(2024)
modelo.run(dados_, precision = 0.1)
print(modelo)
plot_expected(modelo, dados_)
```

![EX_4](free_regression/imagens_testes/reg_4_log.png)

![EX_18](free_regression/imagens_testes/res_18.png)

![EX_5](free_regression/imagens_testes/reg_5_sigmoid.png)

![EX_19](free_regression/imagens_testes/res_19.png)

### Cadeia de Markov com multiplas dependências

```
from free_regression import Generator

text = """COLOQUE SEU TEXTO AQUI, VÁRIAS LINHAS DE TEXTO"""

for dependence in range(1, 10, 1):
  test = Generator(dependence = dependence)
  test.train(list(text))
  #print(test.chain)
  #print(test.prob_chain)
  #print(test.choice(["t", "a"]))
  resp:str = test.make_text(list("Por fim, a resiliencia"), lenth = 200)
  print(f"\nDependenci: {'='*200}\n{dependence} -> {resp}\n")
```

### Série temporal

```
from random import random, seed
from free_regression import Regression, plot_series, data_series
    
seed(1)

def ar_2(y1, y2, b1, b2, b3):
    return y1 * b1 + y2 * b2 + b3

phi = [0.45, -0.95]
data = [1, 2]
for i in range(200):
    data.append(phi[0] * data[-1] + phi[1] * data[-2] + 5 + (random() + random() + random()) )

data = data_series(data, p = 2)
model_ar_2 = Regression(ar_2, regressors = ["y1", "y2"])
model_ar_2.set_seed(1)
model_ar_2.iterations = 1000
model_ar_2.run(data, especific_precision = [1, 0.1, 0.01])
print(model_ar_2)
a = model_ar_2.prediction([data[i][:-1] for i in range(len(data))])
for i in range(len(data)):
    print(data[i][-1], a[i])

plot_series(model_ar_2, data, size = (14, 8))
```

Saída:

```
FUNCTION: ar_2
LOSS FUNCTION(least_squares): 0.26035616
REGRESSORS: y1, y2
LENTH OUTPUT: 1 (UNIVARIATE)
PARAMS:
  b1 = -0.97013635 (w: 0.07102360)
  b2 = 0.42563299 (w: 0.08974967)
  b3 = 6.70987577 (w: 1.00000000)
```

![EX_TEMPORAL_SERIES_1](free_regression/imagens_testes/ts_1.png)

### Função dependente em função idependente

Transformando função dependente:

$$ f(x) = b_{1} \cdot f(x-1) + b_{2} \cdot f(x-2) $$

em função idependente

$$ f(x) = c_{1} \cdot \lambda_{1}^{x} + c_{2} \cdot \lambda_{2}^{x} $$

```
from random import random, seed
from free_regression import Regression, plot_expected

# Dados ########################################
dados = [0, 1]
for _ in range(8):
  dados.append(-0.8*dados[-1] + 1.2*dados[-2])

dados = [[i, x] for i, x in enumerate(dados)]
print(dados)

# Modelo ########################################
def f(x:float, a:float, b:float, c:float, d:float) -> float:
  return a*b**x + c*d**x

modelo = Regression(f, print = True)
modelo.set_seed(1)
modelo.lock(d = dados[-1][1]/dados[-2][1]) # Aproximação de uma das raizes

modelo.run(dados)

# Resultado ######################################
print(modelo)
plot_expected(modelo, dados)
```

Saída:

```
LOSS FUNCTION(least_squares): 0.00268481
REGRESSORS: x
LENTH OUTPUT: 1 (UNIVARIATE)
LOCK PARAMS: d
PARAMS:
  a = 0.42870316 (w: 0.99981393)
  b = 0.75958136 (w: 1.00000000)
  c = -0.41167104 (w: 0.99981393)
  d = -1.57386689 (w: 1.00000000)
```

![EX_FUNC_DEPENDENTE_PARA_IDEPENDENTE](free_regression/imagens_testes/func_dep_para_idep.png)


### MCMC (Markov Chain Monte Carlo)

```
from free_regression import Generator, plot_time_series, round_series
from random import random, seed
from math import cos

seed(2)
text = [cos(i/7) + cos(i/3) - cos(cos(i/17) + random() - 0.5) for i in range(3_000)]
text = round_series(text, n = 40)

print(f"Valores: {sorted(set(text))}")
test = Generator(dependence = 2)
test.train(list(text))
resp = plot_time_series(generator = test,
                        sequence = text[400:405],
                        lenth = 30,
                        times = 1000)
```

![EX_MCMC_1](free_regression/imagens_testes/mcmc_1.png)

```
from free_regression import Generator, mcmc_anomaly
from random import random, seed
from math import cos

seed(0)
dados = [10 + int(random()+random()+random()+cos(i/10)*30) for i in range(50_000)]
dados_prev = dados[100:300]

mcmc_anomaly(dados, dados_prev,
             dependence = 2,
             percentage = 10)
```

### Montando redutor de dimensionalidade

Redutor de dimensionalidade de $\mathbb{R}^3 \to \mathbb{R}^2$

```
from free_regression import Regression
from random import random, seed


# Funções ##################################################
def relu(x:float) -> float:
  return x if x >= 0 else x/10

def f(x1, x2, x3, w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16, w17) -> (float, float, float):
  c11:float = relu(x1*w1 + x2*w2 + x3*w3 + w16)
  c12:float = relu(x1*w4 + x2*w5 + x3*w6 + w17)
  return [c11*w7 + c12*w8 + w13, c11*w9 + c12*w10 + w14, c11*w11 + c12*w12 + w15]

def f_parc(x1, x2, x3, w1, w2, w3, w4, w5, w6, w16, w17) -> (float, float):
  c11:float = relu(x1*w1 + x2*w2 + x3*w3 + w16)
  c12:float = relu(x1*w4 + x2*w5 + x3*w6 + w17)
  return [c11, c12]

# Dados ####################################################
seed(1)

dados_1, dados_2, dados_3, dados_4, dados_5 = [], [], [], [], []

for _ in range(7):
  temp = [random(), random(), random()]
  temp = [*temp, *temp]
  dados_1.append(temp.copy())

for _ in range(7):
  temp = [random() + 1, random(), random()]
  temp = [*temp, *temp]
  dados_2.append(temp.copy())

for _ in range(7):
  temp = [random(), random() + 1, random()]
  temp = [*temp, *temp]
  dados_3.append(temp.copy())

for _ in range(7):
  temp = [random(), random(), random() + 1]
  temp = [*temp, *temp]
  dados_4.append(temp.copy())

for _ in range(7):
  temp = [random() + 1, random() + 1, random() + 1]
  temp = [*temp, *temp]
  dados_5.append(temp.copy())

dados = [*dados_1, *dados_2, *dados_3, *dados_4, *dados_5]
colors = [*["blue"] * 7, *["red"] * 7, *["green"] * 7, *["grey"] * 7, *["pink"] * 7]

# Modelo ####################################################
modelo = Regression(f, print = True)
modelo.set_seed(1)

modelo.run(dados)
print(modelo)
```

Saída

```
FUNCTION: f
LOSS FUNCTION(least_squares_multivariate): 0.25298512
REGRESSORS: x1, x2, x3
LENTH OUTPUT: 3 (MULTIVARIATE)
PARAMS:
  w1 = 1.40160852 (w: 0.99609845)
  w2 = 1.20905211 (w: 0.99240304)
  w3 = 1.90383075 (w: 0.99379174)
  w4 = 1.29010370 (w: 0.99609845)
  w5 = -0.42315787 (w: 0.99240304)
  w6 = 0.43193659 (w: 0.99379174)
  w7 = 0.00722119 (w: 0.97849836)
  w8 = 0.62503256 (w: 0.97849836)
  w9 = 0.33884257 (w: 0.97258454)
  w10 = -0.56880160 (w: 0.97258454)
  w11 = 0.30476131 (w: 0.97627600)
  w12 = -0.09723028 (w: 0.97627600)
  w13 = 0.00903604 (w: 0.88725152)
  w14 = 0.50654604 (w: 0.87470719)
  w15 = -0.07919318 (w: 0.88812425)
  w16 = -0.48020186 (w: 1.00000000)
  w17 = 0.23674088 (w: 1.00000000)
```

Plotando:

```
import matplotlib.pyplot as plt

modelo_parc = Regression(f_parc)
modelo_parc << modelo # Pasando os pesos para o modelo parcial que permite vizualizar em 2d
print(modelo_parc)

x, y = zip(*modelo_parc.prediction([x_[:3] for x_ in dados]))


plt.scatter(x, y, c = colors, alpha = 0.4, s = 100)

plt.title("Redução de dimensionalidade")
plt.xlabel("Eixo X")
plt.ylabel("Eixo Y")

plt.show()

################################################################

x, y, z = zip(*[x_[:3] for x_ in dados])

for a, b in [[0, 0], [0, 45], [0, 90], [45, 90], [90, 90]]:

  fig = plt.figure()
  ax = fig.add_subplot(111, projection='3d')

  ax.scatter(x, y, z, c = colors, s = 100, alpha = 0.4)
  ax.view_init(elev = a, azim = b)

  ax.set_title(f"Gráfico de Dispersão 3D ({a}, {b})")
  ax.set_xlabel("Eixo X")
  ax.set_ylabel("Eixo Y")
  ax.set_zlabel("Eixo Z")
```

Saída:

```
FUNCTION: f_parc
LOSS FUNCTION: least_squares_multivariate
REGRESSORS: x1, x2, x3
LENTH OUTPUT: 2 (MULTIVARIATE)
PARAMS:
  w1 = 1.40160852 (w: 0.99609845)
  w2 = 1.20905211 (w: 0.99240304)
  w3 = 1.90383075 (w: 0.99379174)
  w4 = 1.29010370 (w: 0.99609845)
  w5 = -0.42315787 (w: 0.99240304)
  w6 = 0.43193659 (w: 0.99379174)
  w16 = -0.48020186 (w: 1.00000000)
  w17 = 0.23674088 (w: 1.00000000)
```

![EX_red_1](free_regression/imagens_testes/red_dim_1.png)

![EX_red_2](free_regression/imagens_testes/red_dim_2.png)

![EX_red_3](free_regression/imagens_testes/red_dim_3.png)

![EX_red_4](free_regression/imagens_testes/red_dim_4.png)


Segundo exemplo reduzindo a dimensionalidade:

```
def s(x:float) -> float:
  return x

def f(x1, x2, x3, w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12, w13, w14, w15, w16, w17) -> (float, float, float):
  c11:float = s(x1*w1 + x2*w2 + x3*w3 + w16)
  c12:float = s(x1*w4 + x2*w5 + x3*w6 + w17)
  return [c11*w7 + c12*w8 + w13, c11*w9 + c12*w10 + w14, c11*w11 + c12*w12 + w15]

def f_parc(x1, x2, x3, w1, w2, w3, w4, w5, w6, w16, w17) -> (float, float):
  c11:float = s(x1*w1 + x2*w2 + x3*w3 + w16)
  c12:float = s(x1*w4 + x2*w5 + x3*w6 + w17)
  return [c11, c12]
  
################################################################

from random import random, seed
seed(1)

dados_1, dados_2, dados_3, dados_4, dados_5, dados_6, dados_7, dados_8 = [], [], [], [], [], [], [], []
n:int = 2
k:int = 10

for _ in range(k):
  temp = [random(), random(), random()]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_1.append(temp.copy())

for _ in range(k):
  temp = [random() + n, random(), random()]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_2.append(temp.copy())

for _ in range(k):
  temp = [random(), random() + n, random()]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_3.append(temp.copy())

for _ in range(k):
  temp = [random(), random(), random() + n]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_4.append(temp.copy())

for _ in range(k):
  temp = [random() + n, random() + n, random() + n]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_5.append(temp.copy())

for _ in range(k):
  temp = [random(), random() + n, random() + n]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_6.append(temp.copy())

for _ in range(k):
  temp = [random() + n, random(), random() + n]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_7.append(temp.copy())

for _ in range(k):
  temp = [random() + n, random() + n, random()]
  temp = [*temp, [temp[0] - 3, temp[1] - 3, temp[2] - 3]]
  dados_8.append(temp.copy())

dados = [*dados_1, *dados_2, *dados_3, *dados_4, *dados_5, *dados_6, *dados_7, *dados_8]
colors = [*["blue"] * k, *["red"] * k, *["green"] * k, *["grey"] * k, *["pink"] * k, *["yellow"] * k, *["black"] * k, *["purple"] * k]

################################################################

modelo = Regression(f, print = True)
modelo.set_seed(1)
print(modelo)

modelo.run(dados)
#modelo.run_robust(dados)
print(modelo)

################################################################

import matplotlib.pyplot as plt

modelo_parc = Regression(f_parc)
modelo_parc << modelo # Pasando os pesos para o modelo parcial que permite vizualizar em 2d
print(modelo_parc)

x, y = zip(*modelo_parc.prediction([x_[:3] for x_ in dados]))


plt.scatter(x, y, c = colors, alpha = 0.4, s = 100)

plt.title("Redução de dimensionalidade")
plt.xlabel("Eixo X")
plt.ylabel("Eixo Y")

plt.show()

################################################################

x, y, z = zip(*[x_[:3] for x_ in dados])

for a, b in [[0, 0], [0, 45], [0, 90], [45, 90], [90, 90]]:

  fig = plt.figure()
  ax = fig.add_subplot(111, projection='3d')

  ax.scatter(x, y, z, c = colors, s = 100, alpha = 0.4)
  ax.view_init(elev = a, azim = b)

  ax.set_title(f"Gráfico de Dispersão 3D ({a}, {b})")
  ax.set_xlabel("Eixo X")
  ax.set_ylabel("Eixo Y")
  ax.set_zlabel("Eixo Z")
```

Saída:

```
FUNCTION: f
LOSS FUNCTION(least_squares_multivariate): 1.02027349
REGRESSORS: x1, x2, x3
LENTH OUTPUT: 3 (MULTIVARIATE)
PARAMS:
  w1 = -0.21856788 (w: 0.93305773)
  w2 = -0.70089477 (w: 0.92572803)
  w3 = 1.04726199 (w: 0.93224252)
  w4 = 0.19325063 (w: 0.93305773)
  w5 = -0.48449476 (w: 0.92572803)
  w6 = -0.01427655 (w: 0.93224252)
  w7 = -0.31313602 (w: 0.86133541)
  w8 = 1.03627477 (w: 0.86133541)
  w9 = -0.14774773 (w: 0.87091987)
  w10 = -1.62078327 (w: 0.87091987)
  w11 = 0.79111506 (w: 0.86243128)
  w12 = -0.87125258 (w: 0.86243128)
  w13 = -2.36440081 (w: 0.63442108)
  w14 = -0.63719914 (w: 0.64253031)
  w15 = -0.39747654 (w: 0.63532989)
  w16 = -0.93143102 (w: 1.00000000)
  w17 = 1.05927996 (w: 1.00000000)
  
  
FUNCTION: f
LOSS FUNCTION(least_squares_multivariate): 1.02027349
REGRESSORS: x1, x2, x3
LENTH OUTPUT: 3 (MULTIVARIATE)
PARAMS:
  w1 = -0.21856788 (w: 0.93305773)
  w2 = -0.70089477 (w: 0.92572803)
  w3 = 1.04726199 (w: 0.93224252)
  w4 = 0.19325063 (w: 0.93305773)
  w5 = -0.48449476 (w: 0.92572803)
  w6 = -0.01427655 (w: 0.93224252)
  w7 = -0.31313602 (w: 0.86133541)
  w8 = 1.03627477 (w: 0.86133541)
  w9 = -0.14774773 (w: 0.87091987)
  w10 = -1.62078327 (w: 0.87091987)
  w11 = 0.79111506 (w: 0.86243128)
  w12 = -0.87125258 (w: 0.86243128)
  w13 = -2.36440081 (w: 0.63442108)
  w14 = -0.63719914 (w: 0.64253031)
  w15 = -0.39747654 (w: 0.63532989)
  w16 = -0.93143102 (w: 1.00000000)
  w17 = 1.05927996 (w: 1.00000000)
```

![EX_red_5](free_regression/imagens_testes/red_dim_5.png)

![EX_red_6](free_regression/imagens_testes/red_dim_6.png)

![EX_red_7](free_regression/imagens_testes/red_dim_7.png)

![EX_red_8](free_regression/imagens_testes/red_dim_8.png)


## Com dados reais

```
dados = MedidasDeMassa()
dados = transpose([dados["LegLength"], dados["TotalHeight"]])

modelo_1 = Regression(*generate_regression(1, 2))
modelo_1.set_seed(2024)
modelo_1.run(dados)
print(modelo_1)
plot_expected(modelo_1, dados)
plot_residual(modelo_1, dados)
plot_prediction_bands(modelo_1, dados, amplitude = 5, sigma = 1.96)

modelo_2 = Regression(*generate_mlp_sigmoid_sum(1, 2))
modelo_2.set_seed(2024)
modelo_2.run(dados)
print(modelo_2)
plot_expected(modelo_2, dados)
plot_residual(modelo_2, dados)
```

![EX_6](free_regression/imagens_testes/reg_6_pol2.png)

![EX_8](free_regression/imagens_testes/res_8.png)

![EX_16](free_regression/imagens_testes/reg_16.png)

![EX_7](free_regression/imagens_testes/reg_7_sum_sigmoid.png)

![EX_9](free_regression/imagens_testes/res_9.png)

```
# Predição
print(f"Modelo 1 com 'LegLength' = 80cm -> {modelo_1.prediction(x_1 = 80/1.6):0.03f} polegadas")
print(f"Modelo 2 com 'LegLength' = 80cm -> {modelo_2.prediction(x0 = 80/1.6):0.03f} polegadas")
```

```
dados = MedidasDeMassa()
dados = transpose([dados[1], dados["TotalHeight"]])

modelo = Regression(reg_mult)
modelo.set_seed(2024)
modelo.change(b0 = 0, b1 = 90, b2 = 0, b3 = 30)
modelo.run(dados, precision = 0.1)
print(modelo)

plot_prediction_bands(modelo, dados, amplitude = 1.5)
```

![EX_17](free_regression/imagens_testes/res_17.png)

### Usando variáveis dummys

```
dados = ProdutividadeTrabalhoRemoto()
print(dados)

dados_mod = transpose([dados["Hours_Worked_Per_Week"], dados["Employment_Type"]])
dados_mod_1 = to_dummy(dados_mod)

dados_mod_2 = to_dummy(dados[:])

def regressao_logistica(x:float, a:float, b:float) -> float:
  return 1/(1+2.7183**(a*x + b))
  
modelo_1 = Regression(regressao_logistica)
modelo_1.set_seed(2024)
modelo_1.run(dados_mod_1, precision = 0.1)
print(modelo_1)

modelo_2 = Regression(*generate_mlp_semi_classifier(regressors = 1, neurons = 1))
modelo_2.set_seed(2024)
modelo_2.run(dados_mod_1, precision = 0.1)
print(modelo_2)

plot_expected(modelo_1, dados_mod_1)
plot_expected(modelo_2, dados_mod_1)

def regressao_logistica_multipla(x1:float, x2:float, x3:float, a:float, b:float, c:float, d:float) -> float:
  return 1/(1+2.7183**(a*x1 + b*x2 + c*x2 + d))
  
modelo_3 = Regression(regressao_logistica_multipla, regressors = ["x1", "x2", "x3"])
modelo_3.set_seed(2024)
modelo_3.run(dados_mod_2, precision = 0.01)
print(modelo_3)

modelo_4 = Regression(*generate_mlp_semi_classifier(regressors = 3, neurons = 2))
modelo_4.set_seed(2024)
modelo_4.run(dados_mod_2, precision = 0.1)
print(modelo_4)

modelo_5 = Regression(*generate_mlp_classifier(regressors = 3, neurons = 2))
modelo_5.set_seed(2024)
modelo_5.run(dados_mod_2, precision = 1)
print(modelo_5)

print(f"OBSERVADO | MODELO_1 | MODELO_2 | MODELO_3")
for *x, y in dados_mod_2:
  MODELO_1 = 1 if modelo_3.prediction([x])[0] >= 0.5 else 0
  MODELO_2 = 1 if modelo_4.prediction([x])[0] >= 0.5 else 0
  MODELO_3 = 1 if modelo_5.prediction([x])[0] >= 0.5 else 0
  print(f"{y:10}|{MODELO_1:10}|{MODELO_1:10}|{MODELO_1:10}")

num_acertos = [0, 0, 0]
for *x, y in dados_mod_2:
  MODELO_1 = 1 if modelo_3.prediction([x])[0] >= 0.5 else 0
  MODELO_2 = 1 if modelo_4.prediction([x])[0] >= 0.5 else 0
  MODELO_3 = 1 if modelo_5.prediction([x])[0] >= 0.5 else 0
  
  i = 0
  MODELOS = [MODELO_1, MODELO_2, MODELO_3]
  for MODELO in MODELOS:
    if MODELO == y:
      num_acertos[i] += 1
    i += 1

for i in range(len(num_acertos)):
  num_acertos[i] /= len(dados_mod_2)

print(f"\nMODELO_1: {num_acertos[0]*100:2.02f}%\nMODELO_2: {num_acertos[1]*100:2.02f}%\nMODELO_3: {num_acertos[2]*100:2.02f}%")
```

![EX_10](free_regression/imagens_testes/reg_10.png)

![EX_11](free_regression/imagens_testes/reg_11.png)




